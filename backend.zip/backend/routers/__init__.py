from .orders import router as orders_router
from .couriers import router as couriers_router
from .dispatch import router as dispatch_router
from .auth import router as auth_router
